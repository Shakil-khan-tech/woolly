<!-- Web Application Manifest -->
<link rel="manifest" href="/manifest.json">
<!-- Chrome for Android theme color -->
<meta name="theme-color" content="#F5A100">

<!-- Add to homescreen for Chrome on Android -->
<meta name="mobile-web-app-capable" content="yes">
<meta name="application-name" content="The Shop">
<link rel="icon" sizes="512x512" href="<?php echo e(uploaded_asset(get_setting('site_icon'))); ?>">

<!-- Add to homescreen for Safari on iOS -->
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-title" content="The Shop">
<link rel="apple-touch-icon" href="<?php echo e(uploaded_asset(get_setting('site_icon'))); ?>">


<link href="<?php echo e(static_asset('web-assets/img/icons/splash-640x1136.png')); ?>" media="(device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-750x1334.png')); ?>" media="(device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1242x2208.png')); ?>" media="(device-width: 621px) and (device-height: 1104px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1125x2436.png')); ?>" media="(device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-828x1792.png')); ?>" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1242x2688.png')); ?>" media="(device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1536x2048.png')); ?>" media="(device-width: 768px) and (device-height: 1024px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1668x2224.png')); ?>" media="(device-width: 834px) and (device-height: 1112px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-1668x2388.png')); ?>" media="(device-width: 834px) and (device-height: 1194px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />
<link href="<?php echo e(static_asset('web-assets/img/icons/splash-2048x2732.png')); ?>" media="(device-width: 1024px) and (device-height: 1366px) and (-webkit-device-pixel-ratio: 2)" rel="apple-touch-startup-image" />

<!-- Tile for Win8 -->
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="<?php echo e(uploaded_asset(get_setting('site_icon'))); ?>">

<script type="text/javascript">
    // Initialize the service worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/serviceworker.js', {
            scope: '/'
        }).then(function (registration) {
            // Registration was successful
            // console.log('Laravel PWA: ServiceWorker registration successful with scope: ', registration.scope);
        }, function (err) {
            // registration failed :(
            console.log('The Shop PWA: ServiceWorker registration failed: ', err);
        });
    }
</script><?php /**PATH C:\Shakil-Dev\Xampp\htdocs\the_shop\resources\views/frontend/inc/pwa.blade.php ENDPATH**/ ?>