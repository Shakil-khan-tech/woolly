UPDATE `settings` SET `value` = '1.0.1' WHERE `type` = 'current_version';

COMMIT;
