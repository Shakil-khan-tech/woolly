UPDATE `settings` SET `value` = '1.5' WHERE `type` = 'current_version';

COMMIT;