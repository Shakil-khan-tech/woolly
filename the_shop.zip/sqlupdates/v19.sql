UPDATE `settings` SET `value` = '1.9' WHERE `type` = 'current_version';

COMMIT;